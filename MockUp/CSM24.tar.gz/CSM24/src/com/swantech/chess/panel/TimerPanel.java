package com.swantech.chess.panel;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;


public class TimerPanel extends JPanel {
	private JLabel nameLable;
	private JLabel nameValueLable;
	private JLabel winLable;
	private JLabel winValueLable;
	private JLabel lostLable;
	private JLabel lostValueLable;
	private JLabel drawLable;
	private JLabel drawValueLable;
	
	public TimerPanel(){
		nameLable = new JLabel("Ramaining time:");
		nameValueLable = new JLabel("12:45");
		
		Dimension dim = getPreferredSize();
		dim.width = 223;
		//dim.height = 223;
		setPreferredSize(dim);
		
		
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		
		gbc.weightx = gbc.weighty = 0.05;
		gbc.gridx = gbc.gridy = 0;	
		
		gbc.fill = GridBagConstraints.NORTH;		
		gbc.anchor = GridBagConstraints.FIRST_LINE_START;		
		gbc.insets = new Insets(0,10,0,0); 
		add(nameLable, gbc);
		
		gbc.gridx++;
		gbc.fill = GridBagConstraints.NORTH;		
		gbc.anchor = GridBagConstraints.FIRST_LINE_END;		
		gbc.insets = new Insets(0,10,0,0); 
		add(nameValueLable, gbc);
		

		
		Border innerBorder = BorderFactory.createTitledBorder("Timer");
		Border outterBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		setBorder(BorderFactory.createCompoundBorder(outterBorder, innerBorder)	);
	}
}
