package com.swantech.chess;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;


public class ButtomToolbar extends JPanel implements ActionListener{
	private JButton btnStart, btnStop;
	private StringListener btnListener;
	
	public ButtomToolbar(){
		btnStart = new JButton("Start");
		btnStop = new JButton("Stop");
		
		btnStart.addActionListener(this);
		btnStop.addActionListener(this);
		
		setLayout(new FlowLayout());
		add(btnStart);
		add(btnStop);
		
	}
	
	public void setStringListener(StringListener listener){
		this.btnListener = listener;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton clicked = (JButton)e.getSource();
		
		if(clicked == btnStart){
			if(btnListener != null){
				btnListener.textEmitter("Start\n\n");
			}
			
		}else if(clicked == btnStop){
			if(btnListener != null){
				btnListener.textEmitter("Stop\n\n");
			}
		} else{
			
		}
	}
}
