package com.swantech.chess;

public interface StringListener {
	public void textEmitter(String text);
	public void clear();
}
