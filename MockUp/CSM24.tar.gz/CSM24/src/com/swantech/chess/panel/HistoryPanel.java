package com.swantech.chess.panel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;


public class HistoryPanel extends JPanel {
	
	private JTextArea textArea;
	
	public HistoryPanel(){
		textArea = new JTextArea();
		setLayout(new BorderLayout());
		textArea.setEditable(false);
		//textArea.setEnabled(false);
		add(new JScrollPane(textArea), BorderLayout.CENTER);
		String gameHistory = "1. Kd4 Kf6 \n2. Kd5 Kf5 \n3. Kd6 Ke4 \n4. Ke7 Kd4 "
						   + "\n5. Ke6 Kc5 \n6. Kf5 Kd5 \n7. Kf4 Ke6";
		appendText(gameHistory);
		
		
		Dimension dim = getPreferredSize();
		dim.width = 223;
		//dim.height = 223;
		setPreferredSize(dim);
		
		
		Border innerBorder = BorderFactory.createTitledBorder("History");
		Border outterBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		setBorder(BorderFactory.createCompoundBorder(outterBorder, innerBorder)	);
	}
	
	public void appendText(String text){
		textArea.append(text);
	}
	
	/**
	 * Clear the TextArea
	 * This method is used when user try to load another file
	 */
	public void clear(){
		textArea.setText(null);
	}
}
