package com.swantech.chess;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

public class NewGameDialog extends JDialog {
	
	private JButton okButton;
	private JButton cancelButton;
	private JRadioButton friendRadioButton;
	private JRadioButton computerRadioButton;
	private JRadioButton networkRadioButton;
	private ButtonGroup gameTypeButtonGroup;
	
	
	public NewGameDialog(JFrame parent){
		super(parent, "New Game...", false);
		
		okButton = new JButton("OK");
		cancelButton = new JButton("Cancel");
		friendRadioButton = new JRadioButton("Play with friend in this computer");
		computerRadioButton = new JRadioButton("Play with computer in this computer");
		networkRadioButton = new JRadioButton("Play with friend or computer with network");
		gameTypeButtonGroup = new ButtonGroup();
		
		gameTypeButtonGroup.add(friendRadioButton);
		gameTypeButtonGroup.add(computerRadioButton);
		gameTypeButtonGroup.add(networkRadioButton);
		
		friendRadioButton.setSelected(true);
		
		
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();

		
		gbc.weightx = 1.0;
		//gbc.weighty = GridBagConstraints.REMAINDER;
		//gbc.weighty = GridBagConstraints.RELATIVE;
		gbc.weighty = 1.0;

		gbc.gridx= 0;
		gbc.gridy = 0;
		
		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.fill = GridBagConstraints.NONE;
		gbc.insets = new Insets(0,10,0,0); 
		add(friendRadioButton, gbc);
		
		gbc.gridy++;
		//gbc.weighty = 0.05;   //request any extra vertical space
		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(0,10,0,0); 
		add(computerRadioButton, gbc);
		
		gbc.gridy++;
		//gbc.weighty = 0.009;
		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(0,10,0,0); 
		add(networkRadioButton, gbc);
		
		
		gbc.gridx = 0;
		gbc.gridy++;
		gbc.anchor = GridBagConstraints.LINE_END;
		add(okButton, gbc);

		gbc.gridx++;		
		gbc.anchor = GridBagConstraints.LINE_END;
		gbc.insets = new Insets(0,0,0,10); 
		add(cancelButton, gbc);

		okButton.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent e) {
				//TODO: do something
				setVisible(false);
				
			}
		});
		
		cancelButton.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				
			}
		});
		
		setSize(450, 300);
		setMaximumSize(new Dimension(450,300));
		setMinimumSize(new Dimension(450,300));
		setLocationRelativeTo(parent);
		
		
		
		
	}
}
