package com.swantech.chess;

import javax.swing.SwingUtilities;

public class Main {

	public static void main(String[] args) {
		// stop error in java 4
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new MainFrame();
			}
		});

	}
}
