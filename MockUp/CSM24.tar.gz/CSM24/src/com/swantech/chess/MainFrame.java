package com.swantech.chess;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.BoxLayout;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;

import com.swantech.chess.panel.BestUserPanel;
import com.swantech.chess.panel.BoardPanel;
import com.swantech.chess.panel.HistoryPanel;
import com.swantech.chess.panel.LeftPanel;
import com.swantech.chess.panel.MyProfilePanel;
import com.swantech.chess.panel.TimerPanel;

public class MainFrame extends JFrame {

	private NewGameDialog newGameDialog;
	
	private MyProfilePanel myProfilePanel;
	private BestUserPanel bestUserPanel;
	private LeftPanel leftPanel;
	
	private BoardPanel boardPanel;
	private TimerPanel timerPanel;
	private HistoryPanel historyPanel;

	private KeyEvent virtualKey;
	
	
	public MainFrame() {
		super("Chess - SwanTech");

		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		
		gbc.weightx = gbc.weighty = 1.0;
		gbc.gridx = gbc.gridy = 0;	
		//gbc.ipadx = 1;
				
		newGameDialog = new NewGameDialog(this);
		
		myProfilePanel = new MyProfilePanel();
		bestUserPanel = new BestUserPanel();
		leftPanel = new LeftPanel();
		
		boardPanel = new BoardPanel();
		timerPanel = new TimerPanel();
		historyPanel = new HistoryPanel();
		
		setJMenuBar(MenuBar());
		
		/*
		setLayout(new BorderLayout());
		
		//add(myProfilePanel, BorderLayout.NORTH);
		add(timerPanel, BorderLayout.NORTH);
		add(myProfilePanel, BorderLayout.EAST);
		add(boardPanel, BorderLayout.CENTER);
		//add(timerPanel, BorderLayout.NORTH);
		add(historyPanel, BorderLayout.WEST);
		*/
		
		gbc.fill = GridBagConstraints.BOTH;
		gbc.anchor = GridBagConstraints.FIRST_LINE_START;		
		gbc.insets = new Insets(0,10,0,0); 
		add(myProfilePanel, gbc);
		
		gbc.gridy++;
		gbc.anchor = GridBagConstraints.LAST_LINE_START;		
		gbc.insets = new Insets(0,10,0,0); 
		add(bestUserPanel, gbc);
				
		gbc.gridy = 0;
		gbc.gridx = 1;
		//gbc.weighty = 2;
		gbc.anchor = GridBagConstraints.CENTER;
		gbc.fill = GridBagConstraints.BOTH;		
		gbc.insets = new Insets(50,60,0,0); 
		gbc.gridheight = 2;
		gbc.gridwidth = 2;
		gbc.ipadx = 400;
		JTextArea textt;
		textt = new JTextArea();
		add(boardPanel, gbc);
		
		gbc.fill = GridBagConstraints.VERTICAL;
		gbc.gridx = 3;
		gbc.ipadx = 1;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.FIRST_LINE_END;
		///gbc.fill = GridBagConstraints.NONE;
		gbc.insets = new Insets(0,10,0,0); 
		add(timerPanel, gbc);
		
		gbc.gridy++;
		gbc.anchor = GridBagConstraints.LAST_LINE_END;		
		gbc.insets = new Insets(0,10,0,0); 
		add(historyPanel, gbc);
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setMinimumSize(new Dimension(640, 480));
		setSize(1024, 690);
		setVisible(true);

		setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH); //Run
		// the app in MAXIMIZE version
	}

	private JMenuBar MenuBar() {
		JMenuBar menuBar = new JMenuBar();

		JMenu gameMenu = new JMenu("Game");
		JMenuItem newGameItem = new JMenuItem("New Game...");
		JMenuItem exitItem = new JMenuItem("Exit");

		gameMenu.add(newGameItem);
		newGameItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newGameDialog.setVisible(true);
			}
		});
		
		gameMenu.addSeparator();
		gameMenu.add(exitItem);

		JMenu userMenu = new JMenu("User");
		JMenuItem newUserItem = new JMenuItem("New User...");
		JMenuItem listOfAllItem = new JMenuItem("List Of All...");
		JMenuItem bestUserItem = new JMenuItem("Best Users...");

		userMenu.add(newUserItem);
		userMenu.add(listOfAllItem);
		userMenu.addSeparator();
		userMenu.add(bestUserItem);

		JMenu helpMenu = new JMenu("Help");
		JMenuItem welcomeItem = new JMenuItem("Welcome");
		JMenuItem howToPlayItem = new JMenuItem("How To Play");
		JMenuItem lhelpContentsItem = new JMenuItem("Help Contents");
		JMenuItem aboutItem = new JMenuItem("About");

		helpMenu.add(welcomeItem);
		helpMenu.addSeparator();
		helpMenu.add(howToPlayItem);
		helpMenu.add(lhelpContentsItem);
		helpMenu.addSeparator();
		helpMenu.add(aboutItem);

		JMenu windowMenu = new JMenu("Window");
		JMenu showWindowMenu = new JMenu("Show View");

		/* Only because of BoB
		JCheckBoxMenuItem timerItem = new JCheckBoxMenuItem("Timer");
		timerItem.setSelected(true);
		timerItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ev) {
				JCheckBoxMenuItem menuItem = (JCheckBoxMenuItem) ev.getSource();
				timerPanel.setVisible(menuItem.isSelected());
			}
		});

		JCheckBoxMenuItem historyItem = new JCheckBoxMenuItem("History");
		historyItem.setSelected(true);
		historyItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent ev) {
				JCheckBoxMenuItem menuItem = (JCheckBoxMenuItem) ev.getSource();
				historyPanel.setVisible(menuItem.isSelected());
			}
		});

		JCheckBoxMenuItem rankingItem = new JCheckBoxMenuItem("Ranking");
		rankingItem.setSelected(true);
		rankingItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				JCheckBoxMenuItem menuItem = (JCheckBoxMenuItem) ev.getSource();
				bestUserPanel.setVisible(menuItem.isSelected());
			}
		});
		
		JCheckBoxMenuItem myProfileItem = new JCheckBoxMenuItem("My Profile");
		myProfileItem.setSelected(true);
		myProfileItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				JCheckBoxMenuItem menuItem = (JCheckBoxMenuItem) ev.getSource();
				myProfilePanel.setVisible(menuItem.isSelected());
			}
		});
		*/

		//showWindowMenu.add(timerItem);
		showWindowMenu.add(checkBoxMenuItem("Timer", true, timerPanel));
		
		//showWindowMenu.add(historyItem);
		showWindowMenu.add(checkBoxMenuItem("History", true, historyPanel));
		
		//showWindowMenu.add(rankingItem);
		showWindowMenu.add(checkBoxMenuItem("Ranking", true, bestUserPanel));
		
		//showWindowMenu.add(myProfileItem);		
		showWindowMenu.add(checkBoxMenuItem("My Profile", true, myProfilePanel));

		JMenuItem resetPrespectiveItem = new JMenuItem("Reset Prespective");

		windowMenu.add(showWindowMenu);
		windowMenu.addSeparator();
		windowMenu.add(resetPrespectiveItem);

		menuBar.add(gameMenu);
		menuBar.add(userMenu);
		menuBar.add(windowMenu);
		menuBar.add(helpMenu);

		gameMenu.setMnemonic(KeyEvent.VK_G);
		userMenu.setMnemonic(KeyEvent.VK_U);
		windowMenu.setMnemonic(KeyEvent.VK_W);
		helpMenu.setMnemonic(KeyEvent.VK_H);

		newGameItem.setMnemonic(KeyEvent.VK_N);
		newGameItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
		
		exitItem.setMnemonic(KeyEvent.VK_X);
		exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, ActionEvent.CTRL_MASK));
		exitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				int action = JOptionPane.showConfirmDialog(MainFrame.this, "Do you want to leave the game?", "Confirm Exit", JOptionPane.OK_CANCEL_OPTION);
				if (action == JOptionPane.OK_OPTION) {
					System.exit(0);
				}
			}
		});

		return menuBar;
	}
	
	private JCheckBoxMenuItem checkBoxMenuItem(String name, boolean isSelected, final JPanel relatedPanel){

		JCheckBoxMenuItem checkBoxMenuItemName = new JCheckBoxMenuItem(name);
		
		if(isSelected == true){
			checkBoxMenuItemName.setSelected(true);
		}
		checkBoxMenuItemName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				JCheckBoxMenuItem menuItem = (JCheckBoxMenuItem) ev.getSource();
				relatedPanel.setVisible(menuItem.isSelected());
			}
		});
		return checkBoxMenuItemName;
	}
}
