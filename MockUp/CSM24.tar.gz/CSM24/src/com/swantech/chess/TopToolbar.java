package com.swantech.chess;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.commons.io.FileUtils;

public class TopToolbar extends JPanel implements ActionListener {
	private JLabel fileLabel;
	private JTextField fileTextBox;
	private JButton btnLoad;

	private StringListener btnListener;

	public TopToolbar() {
		fileLabel = new JLabel("File name: ");
		fileTextBox = new JTextField(37);
		btnLoad = new JButton("Load");

		btnLoad.addActionListener(this);

		/* GridBagLayout */
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();

		/* First row */
		gbc.weightx = 1.0;
		gbc.weighty = 0.1;

		gbc.gridx = 0;
		gbc.gridy = 0;

		gbc.fill = GridBagConstraints.NONE; // needs to be write only once
		gbc.anchor = GridBagConstraints.LINE_END;
		gbc.insets = new Insets(5, 0, 5, 5); // Margin TOP - LEFT - BUTTOM -
												// RIGHT
		add(fileLabel, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;

		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(5, 5, 5, 0); // Margin TOP - LEFT - BUTTOM -
												// RIGHT
		add(fileTextBox, gbc);

		gbc.gridx = 2;
		gbc.gridy = 0;

		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(5, 5, 5, 0); // Margin TOP - LEFT - BUTTOM -
												// RIGHT
		add(btnLoad, gbc);

	}

	public void setStringListener(StringListener listener) {
		this.btnListener = listener;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton clicked = (JButton) e.getSource();

		if (clicked == btnLoad) {
			if (btnListener != null) {
				try {
					btnListener.clear();

					String fileName = this.fileTextBox.getText();
					if (fileName.length() < 3) {
						btnListener.textEmitter("File name is not valid");
					} else {

						File inputFile = new File(fileName);
						String text = FileUtils.readFileToString(inputFile);
						btnListener.textEmitter(text);
					}
				} catch (IOException e1) {
					btnListener.textEmitter(e1.getMessage());
					btnListener.textEmitter("\nThere is an error with input file path...\n");
					btnListener.textEmitter("Check agian and type the name correctly.\n");
					
				}
			}
		} else {
			// Do Nothing
		}
	}

}
