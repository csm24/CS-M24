package com.swantech.chess.panel;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JFrame;

public class LeftPanel  extends JFrame {

	private MyProfilePanel myProfilePanel;
	private BestUserPanel bestUserPanel;
	
	public LeftPanel(){
		myProfilePanel = new MyProfilePanel();
		bestUserPanel = new BestUserPanel();
		
		setPreferredSize(new Dimension(250,350));
		
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		
		gbc.weightx = gbc.weighty = 1.0;
		gbc.gridx = gbc.gridy = 0;		
		gbc.fill = GridBagConstraints.NONE;
		
		
		gbc.anchor = GridBagConstraints.NORTH;		
		gbc.insets = new Insets(0,10,0,0); 
		add(myProfilePanel, gbc);
		
		gbc.gridy++;
		gbc.anchor = GridBagConstraints.SOUTH;		
		gbc.insets = new Insets(0,10,0,0); 
		add(bestUserPanel, gbc);
		
		
		
		//Border innerBorder = BorderFactory.createTitledBorder("My profile");
		//Border outterBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		//setBorder(BorderFactory.createCompoundBorder(outterBorder, innerBorder)	);
		
	}
}
